export class Country {
    constructor(
      name: String
    ){}
    }