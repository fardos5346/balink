export class Customer{
    constructor(
        public firstName:string,
        public lastName:string,
        public title:string,
        public country:string,
        public city:string,
        public street:string,
        public email:string,
        public phone:string,
        public option:boolean,
    ){}
}