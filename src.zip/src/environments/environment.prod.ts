export const environment = {
  production: true,
  apiUrl: 'https://balinkhw.herokuapp.com'

 
};
